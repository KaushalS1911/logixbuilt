import Herosection from "../components/home/herosection";
import Services from "../components/home/services";


export default function Home() {
    return (
        <>
            <Herosection />
            <Services />

        </>
    );
}
