(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_about_page_jsx_83c9c2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_about_page_jsx_83c9c2._.js",
  "chunks": [
    "static/chunks/_77ca9f._.js"
  ],
  "source": "dynamic"
});
