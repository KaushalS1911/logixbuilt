(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_4011d7.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_4011d7.js",
  "chunks": [
    "static/chunks/node_modules_6f872e._.js",
    "static/chunks/src_9cbab0._.js",
    "static/chunks/node_modules_swiper_62da15._.css"
  ],
  "source": "dynamic"
});
