(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_jsx_4011d7._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_jsx_4011d7._.js",
  "chunks": [
    "static/chunks/node_modules_6f872e._.js",
    "static/chunks/src_dcff99._.js",
    "static/chunks/node_modules_swiper_62da15._.css"
  ],
  "source": "dynamic"
});
