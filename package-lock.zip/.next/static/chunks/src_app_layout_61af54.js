(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_61af54.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_61af54.js",
  "chunks": [
    "static/chunks/[root of the server]__2be27d._.css",
    "static/chunks/node_modules_@mui_material_1f9ce7._.js",
    "static/chunks/node_modules_@mui_system_esm_2a06bc._.js",
    "static/chunks/node_modules_next_ee444e._.js",
    "static/chunks/node_modules_737c87._.js",
    "static/chunks/src_3e3729._.js"
  ],
  "source": "dynamic"
});
